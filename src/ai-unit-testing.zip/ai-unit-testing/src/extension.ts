import * as vscode from 'vscode';
import { exec } from 'child_process';
import * as path from 'path';
import * as fs from 'fs';

export function activate(context: vscode.ExtensionContext) {

  const provider: vscode.WebviewViewProvider = {
    resolveWebviewView(webviewView: vscode.WebviewView) {

      webviewView.webview.options = {
        enableScripts: true
      };

      webviewView.webview.html = getWebviewContent();

      webviewView.webview.onDidReceiveMessage(async msg => {
        if (msg.command === "runPipeline") {
          await runTestGenerationPipeline(context);
        }
      });
    }
  };

  context.subscriptions.push(
    vscode.window.registerWebviewViewProvider(
      "aiUnitTestingView",
      provider
    )
  );
}

function getWebviewContent(): string {
  return `
    <!DOCTYPE html>
    <html>
      <head>
        <style>
          body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            padding: 20px;
            color: var(--vscode-foreground);
            background-color: var(--vscode-editor-background);
          }
          
          h2 {
            margin-top: 0;
            color: var(--vscode-foreground);
            font-weight: 600;
          }
          
          p {
            color: var(--vscode-descriptionForeground);
            margin: 10px 0 20px 0;
            line-height: 1.5;
          }
          
          button {
            background-color: var(--vscode-button-background);
            color: var(--vscode-button-foreground);
            border: none;
            padding: 10px 20px;
            font-size: 14px;
            cursor: pointer;
            border-radius: 2px;
            font-weight: 500;
            width: 100%;
            transition: background-color 0.2s;
          }
          
          button:hover {
            background-color: var(--vscode-button-hoverBackground);
          }
          
          button:active {
            transform: translateY(1px);
          }
          
          .info-box {
            background-color: var(--vscode-textBlockQuote-background);
            border-left: 3px solid var(--vscode-textLink-foreground);
            padding: 12px;
            margin: 15px 0;
            border-radius: 2px;
            font-size: 12px;
          }
          
          .info-box p {
            margin: 0;
          }
        </style>
      </head>
      <body>
        <h2> AI Unit Testing</h2>
        <p>Generate pytest tests from your Python code</p>
        
        <button id="btn">Generate Unit Tests</button>
        
        <div class="info-box">
          <p><strong> How it works:</strong></p>
          <p>Select a Python file, then click the button to generate comprehensive unit tests.</p>
        </div>

        <script>
          const vscode = acquireVsCodeApi();
          
          const btn = document.getElementById("btn");
          
          btn.onclick = () => {
            btn.disabled = true;
            btn.textContent = "Generating...";
            
            vscode.postMessage({ command: "runPipeline" });
            
            // Re-enable after 3 seconds (in case of no response)
            setTimeout(() => {
              btn.disabled = false;
              btn.textContent = "Generate Unit Tests";
            }, 3000);
          };
        </script>
      </body>
    </html>
  `;
}

async function runTestGenerationPipeline(context: vscode.ExtensionContext): Promise<void> {
  try {
    // Step 1: Get workspace
    const workspace = vscode.workspace.workspaceFolders?.[0];
    if (!workspace) {
      vscode.window.showErrorMessage(" No workspace open. Please open a folder first.");
      return;
    }

    // Step 2: Get active editor or let user pick a file
    let targetFile: string | undefined;
    const activeEditor = vscode.window.activeTextEditor;

    if (activeEditor && activeEditor.document.languageId === 'python') {
      // Use active Python file
      targetFile = activeEditor.document.uri.fsPath;
    } else {
      // Let user select a Python file
      const fileUri = await vscode.window.showOpenDialog({
        canSelectFiles: true,
        canSelectFolders: false,
        canSelectMany: false,
        filters: {
          'Python Files': ['py']
        },
        defaultUri: workspace.uri,
        openLabel: 'Select Python File'
      });

      if (!fileUri || fileUri.length === 0) {
        vscode.window.showWarningMessage(" No file selected");
        return;
      }

      targetFile = fileUri[0].fsPath;
    }

    // Step 3: Validate file exists
    if (!fs.existsSync(targetFile)) {
      vscode.window.showErrorMessage(` File not found: ${targetFile}`);
      return;
    }

    // Step 4: Find pipeline script
    const pipelineScript = path.join(context.extensionPath, 'pipeline.py');
    
    if (!fs.existsSync(pipelineScript)) {
      vscode.window.showErrorMessage(
        ` Pipeline script not found at: ${pipelineScript}\n\nPlease ensure pipeline.py is in your extension root.`
      );
      return;
    }

    // Step 5: Prepare output directory
    const outputDir = path.join(workspace.uri.fsPath, 'tests');
    
    // Step 6: Build command
    const pythonCmd = process.platform === 'win32' ? 'python' : 'python3';
    const cmd = `${pythonCmd} "${pipelineScript}" "${targetFile}" -o "${outputDir}"`;

    // Step 7: Show progress
    vscode.window.showInformationMessage(" Generating unit tests...");

    // Step 8: Execute pipeline
    exec(cmd, { 
      cwd: context.extensionPath,
      maxBuffer: 1024 * 1024 * 10 // 10MB buffer for large outputs
    }, (err, stdout, stderr) => {
      
      // Log output for debugging
      console.log('=== Pipeline Output ===');
      console.log(stdout);
      
      if (stderr) {
        console.error('=== Pipeline Errors ===');
        console.error(stderr);
      }

      if (err) {
        // Parse error message for better feedback
        const errorMsg = stderr || err.message;
        
        if (errorMsg.includes('No module named')) {
          const moduleName = errorMsg.match(/No module named '([^']+)'/)?.[1] || 'unknown';
          vscode.window.showErrorMessage(
            ` Missing Python module: ${moduleName}\n\nPlease ensure all required dependencies are installed.`
          );
        } else if (errorMsg.includes('No functions found')) {
          vscode.window.showWarningMessage(
            " No functions found in the selected file.\n\nPlease select a file with testable functions."
          );
        } else {
          vscode.window.showErrorMessage(
            ` Pipeline failed: ${errorMsg.split('\n')[0]}`
          );
        }
        
        // Show detailed output in channel
        const outputChannel = vscode.window.createOutputChannel('AI Unit Testing');
        outputChannel.appendLine('=== Error Details ===');
        outputChannel.appendLine(errorMsg);
        outputChannel.appendLine('\n=== Command ===');
        outputChannel.appendLine(cmd);
        outputChannel.show();
        
        return;
      }

      // Success!
      vscode.window.showInformationMessage(
        ` Unit tests generated successfully!\n\nTests saved to: ${outputDir}`
      );

      // Show output in channel
      const outputChannel = vscode.window.createOutputChannel('AI Unit Testing');
      outputChannel.clear();
      outputChannel.appendLine('=== Test Generation Complete ===\n');
      outputChannel.appendLine(stdout);
      outputChannel.show();

      // Optional: Open the tests folder
      vscode.commands.executeCommand('revealFileInOS', vscode.Uri.file(outputDir));
    });

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    vscode.window.showErrorMessage(` Unexpected error: ${errorMessage}`);
    console.error('Pipeline error:', error);
  }
}

export function deactivate() {}