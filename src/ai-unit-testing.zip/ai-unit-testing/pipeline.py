"""
Main pipeline for AI-powered unit test generation.
Orchestrates extraction, scenario generation, and test creation.
"""

import os
import sys
from typing import Optional
from pathlib import Path


if sys.platform == 'win32':
    try:
        # Try to set UTF-8 encoding
        import codecs
        sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'ignore')
        sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'ignore')
    except:
        # If that fails, disable emojis
        pass

from extract_functions import get_functions_from_file
from generate_scenarios import generate_scenarios_for_functions
from generate_unit_tests import generate_tests_for_functions, save_test_file


# Safe print function that handles emoji encoding issues
def safe_print(text: str):
    """Print text safely, handling Windows encoding issues."""
    try:
        print(text)
    except UnicodeEncodeError:
        # Fallback: remove emojis and special characters
        safe_text = text.encode('ascii', 'ignore').decode('ascii')
        print(safe_text)


class TestGenerationPipeline:
    """Main pipeline for generating unit tests."""
    
    def __init__(self, source_file: str, output_dir: str = "tests"):
        """
        Initialize the pipeline.
        
        Args:
            source_file: Path to Python source file to generate tests for
            output_dir: Directory to save generated test files
        """
        self.source_file = source_file
        self.output_dir = output_dir
        self.functions = []
        self.scenarios = {}
        self.test_files = {}
    
    def validate_source_file(self) -> bool:
        """Validate that the source file exists and is a Python file."""
        if not os.path.exists(self.source_file):
            safe_print(f"[ERROR] File not found: {self.source_file}")
            return False
        
        if not self.source_file.endswith('.py'):
            safe_print(f"[ERROR] Not a Python file: {self.source_file}")
            return False
        
        return True
    
    def extract_functions(self) -> bool:
        """Extract functions from the source file."""
        try:
            safe_print(f"[EXTRACT] Extracting functions from {self.source_file}...")
            self.functions = get_functions_from_file(self.source_file)
            
            if not self.functions:
                safe_print("[WARNING] No functions found in source file")
                return False
            
            safe_print(f"[SUCCESS] Found {len(self.functions)} function(s):")
            for func in self.functions:
                qualified_name = func.get("qualified_name", func.get("func_name"))
                safe_print(f"   - {qualified_name}")
            
            return True
        except Exception as e:
            safe_print(f"[ERROR] Error extracting functions: {e}")
            return False
    
    def generate_scenarios(self) -> bool:
        """Generate test scenarios for extracted functions."""
        try:
            safe_print(f"\n[SCENARIOS] Generating test scenarios...")
            self.scenarios = generate_scenarios_for_functions(self.functions)
            
            total_scenarios = sum(len(s) for s in self.scenarios.values())
            safe_print(f"[SUCCESS] Generated {total_scenarios} scenario(s)")
            
            for func_name, scenarios in self.scenarios.items():
                safe_print(f"   - {func_name}: {len(scenarios)} scenarios")
            
            return True
        except Exception as e:
            safe_print(f"[ERROR] Error generating scenarios: {e}")
            return False
    
    def generate_tests(self) -> bool:
        """Generate test code from scenarios."""
        try:
            safe_print(f"\n[GENERATE] Generating test code...")
            self.test_files = generate_tests_for_functions(self.functions, self.scenarios)
            
            safe_print(f"[SUCCESS] Generated {len(self.test_files)} test file(s)")
            
            return True
        except Exception as e:
            safe_print(f"[ERROR] Error generating tests: {e}")
            return False
    
    def save_tests(self) -> bool:
        """Save generated tests to files."""
        try:
            # Create output directory if it doesn't exist
            os.makedirs(self.output_dir, exist_ok=True)
            
            safe_print(f"\n[SAVE] Saving test files to {self.output_dir}/...")
            
            saved_files = []
            for qualified_name, test_content in self.test_files.items():
                filepath = save_test_file(qualified_name, test_content, self.output_dir)
                saved_files.append(filepath)
                safe_print(f"   [OK] {filepath}")
            
            safe_print(f"\n[SUCCESS] Successfully generated {len(saved_files)} test file(s)!")
            
            return True
        except Exception as e:
            safe_print(f"[ERROR] Error saving tests: {e}")
            return False
    
    def run(self) -> bool:
        """
        Run the complete pipeline.
        
        Returns:
            True if successful, False otherwise
        """
        safe_print("=" * 80)
        safe_print("AI Unit Test Generator Pipeline")
        safe_print("=" * 80)
        
        # Step 1: Validate
        if not self.validate_source_file():
            return False
        
        # Step 2: Extract functions
        if not self.extract_functions():
            return False
        
        # Step 3: Generate scenarios
        if not self.generate_scenarios():
            return False
        
        # Step 4: Generate test code
        if not self.generate_tests():
            return False
        
        # Step 5: Save tests
        if not self.save_tests():
            return False
        
        safe_print("\n" + "=" * 80)
        safe_print("Pipeline completed successfully!")
        safe_print("=" * 80)
        
        return True


def main():
    """CLI entry point."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Generate unit tests for Python functions"
    )
    parser.add_argument(
        "source_file",
        help="Path to Python source file"
    )
    parser.add_argument(
        "-o", "--output",
        default="tests",
        help="Output directory for test files (default: tests)"
    )
    
    args = parser.parse_args()
    
    pipeline = TestGenerationPipeline(args.source_file, args.output)
    success = pipeline.run()
    
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()